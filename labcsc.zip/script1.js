function showMessage() {
    document.getElementById("message").innerText = "Hello! Your static site is deployed on AWS Amplify.";
}
